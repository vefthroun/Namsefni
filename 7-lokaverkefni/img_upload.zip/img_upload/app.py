from flask import Flask, session, render_template, request
import pyrebase

app = Flask(__name__)
app.config['SECRET_KEY'] = 'leyni'

config = {
    # Þú setur þína tenginu hér við Firebase grunninn þinn...
}

fb = pyrebase.initialize_app(config)
db = fb.database()
storage = fb.storage()

# Test route til að setja gögn í db
@app.route('/')
def index():

    data = db.child("Log").get().val()
    data = dict(data.items())

    return render_template("index.html", d = data)

@app.route('/show_reg')
def sr():
    return render_template("reg.html")

@app.route('/reg', methods=["POST"])
def reg():
    if request.method == "POST":
        imgname = request.files["imgname"]
        txt = request.form.get("texti")

        fb_id = db.child("Log").push({"Text":txt,"ImgUrl":"/static/poster.jpg"}) # skrifum harðkóðaða mynd úr static möppu í RtDb hlutann

        id = fb_id['name'] # sækjum firebase id á færslunni sem við vorum að bæta við hér að ofan

        if request.files["imgname"]:
            storage.child('images/'+"logid"+id).put(imgname)
            imgUrl = storage.child('images/'+"logid"+id).get_url(None)
            db.child("Log").child(id).update({"Text":txt,"ImgUrl":imgUrl})

            return "<h1>Færsla í grunn...</h1>"
        else:
             return "<h1>Verður að velja mynd...</h1>"
    else:
         return "<h1>Má ekki!</h1>"

if __name__ == "__main__":
	app.run(debug=True)